package com.example.attdsystem;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
 


public class MainActivity extends Activity implements AnimationListener {

	private boolean mIsBackButtonPressed;
    private static final int SPLASH_DURATION = 4000; //3 seconds
    private Handler myhandler;
  

	ImageView img;
	Animation animt;
	

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		
		super.onCreate(savedInstanceState);
		setContentView(R.layout.blink_anim);

		img = (ImageView) findViewById(R.id.growmore);
		

		// load the animation
		animt = AnimationUtils.loadAnimation(getApplicationContext(),
				R.animator.rotate);
		
		img.setVisibility(View.VISIBLE);
		
		// start the animation
		img.startAnimation(animt);
		
		 myhandler = new Handler();
		  
	        // run a thread to start the home screen
	        myhandler.postDelayed(new Runnable()
	        {
	            @Override
	            public void run()
	            {
	  
	               finish();
	                 
	               if (!mIsBackButtonPressed)
	               {
	                    // start the home activity
	                    Intent intent = new Intent(MainActivity.this, login.class);
	                    MainActivity.this.startActivity(intent);
	               }
	                  
	            }
	  
	        }, SPLASH_DURATION);
	    }
		
		// set animation listener
		//animBlink.setAnimationListener(this);

	@Override
	public void onAnimationEnd(Animation animation) {
		// Take any action after completing the animation

		// check for blink animation
		if (animation == animt) {
			
			
		}

	}

	@Override
	public void onAnimationRepeat(Animation animation) {
		

	}

	@Override
	public void onAnimationStart(Animation animation) {

	}
	
	 @Override
	    public void onBackPressed()
	    {
	        mIsBackButtonPressed = true;
	        super.onBackPressed();
	    }
}
