package com.example.attdsystem;

import javax.security.auth.callback.PasswordCallback;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;

public class login extends Activity {
	
	CheckBox cb;
	PasswordCallback password;
	
	  public void onCreate(Bundle savedInstanceState)
	    {
	        super.onCreate(savedInstanceState);
	        setContentView(R.layout.login);
	        
	     
	    }

	  public void nxtmethod (View v)
	  {
		       // start the home activity
               Intent intent = new Intent(login.this, takeview.class);
               login.this.startActivity(intent);
               
               
          }
	  public void showpassword (View v)
	  {
		    CheckBox cb = (CheckBox)this.findViewById(R.id.showpassword);
		    EditText et1=(EditText)this.findViewById(R.id.edittext2);
		        if(cb.isChecked())
		        {
		        et1.setInputType(InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
		        }
		        else 
		        {
		        et1.setInputType(129);
		        }}
	  public void backmethod(View v)
		{	
		  System.exit(0);
		  finish();
		  
	    }
}