/** Automatically generated file. DO NOT MODIFY */
package com.zaptech.olxdemo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}