package com.zaptech.olxdemo;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class CustomList extends ArrayAdapter<String>{
	private final Activity context;
	private final String[] itemtext;
	private final Integer[] imageid;
	
	 public CustomList(Activity context,
				String[] itemtext, Integer[] imageid) {
				super(context, R.layout.list_row, itemtext);
				this.context = context;
				this.itemtext = itemtext;
				this.imageid = imageid;
				
	 }	
	 @Override
	 public View getView(int position, View view, ViewGroup parent) {
	 	LayoutInflater inflater = context.getLayoutInflater();
	 	View rowView= inflater.inflate(R.layout.list_row, null, true);
	 	TextView txtTitle = (TextView) rowView.findViewById(R.id.textView1);
	 	ImageView imageView = (ImageView) rowView.findViewById(R.id.imageView1);
	 	
	 	txtTitle.setText(itemtext[position]);
	 	imageView.setImageResource(imageid[position]);
	 return rowView;
	 }
	
	

}
