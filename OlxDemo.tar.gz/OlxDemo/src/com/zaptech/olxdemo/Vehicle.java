package com.zaptech.olxdemo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

public class Vehicle extends Activity
{

	  ListView list;
	   String[] itemtext= {
			   "Four Vehiler","Pic_up Van","Bike","Scooter","Auto Rikshaw"
	   };
	   Integer[] imageId={
			   R.drawable.wagonr_logo,
			   R.drawable.picupvan_logo,
			   R.drawable.splendor_logo,
			   R.drawable.scooter_logo,
			   R.drawable.autorickshaw_logo,
			   	   
	   };
		@Override
		protected void onCreate(Bundle savedInstanceState) 
		{
			super.onCreate(savedInstanceState);
			setContentView(R.layout.vehicles); 
			list = (ListView) findViewById(R.id.listView2);
			
				CustomList adapter = new CustomList(Vehicle.this, itemtext, imageId);
				list=(ListView)findViewById(R.id.listView2);
				        list.setAdapter(adapter);
				        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
				                @Override
				                public void onItemClick(AdapterView<?> parent, View view,
				                                        int position, long id) {
				                    if(position==0)
				                    	{
				                    		Intent intent= new Intent(Vehicle.this, MainActivity.class);
				                    		Vehicle.this.startActivity(intent);
				                    	}
				                    
				                   
				                }
				                
				                
				            });

	    }
}
