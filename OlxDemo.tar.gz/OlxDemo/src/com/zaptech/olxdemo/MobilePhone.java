package com.zaptech.olxdemo;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

public class MobilePhone  extends Activity
{
	  ListView list;
	   String[] itemtext= {
			   "samsung","Apple","Nokia","Sony","Motorola","Micromax"
	   };
	   Integer[] imageId={
			   R.drawable.samsung_logo,
			   R.drawable.apple_logo,
			   R.drawable.nokia_logo,
			   R.drawable.sony_logo,
			   R.drawable.moto_logo,
			   R.drawable.micro_logo		   
	   };
	   
	   
	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.mobilephone); 
		list = (ListView) findViewById(R.id.listView1);
		
			CustomList adapter = new CustomList(MobilePhone.this, itemtext, imageId);
			list=(ListView)findViewById(R.id.listView1);
			        list.setAdapter(adapter);
			        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			                @Override
			                public void onItemClick(AdapterView<?> parent, View view,
			                                        int position, long id) {
			                    if(position==0)
			                    	{
			                    		Intent intent= new Intent(MobilePhone.this, MainActivity.class);
			                    		MobilePhone.this.startActivity(intent);
			                    	}
			                    
			                   
			                }
			                
			                
			            });

    }
// method to remove list item
    protected void viewItem(int position) {
        AlertDialog.Builder alert = new AlertDialog.Builder(
                MobilePhone.this);
   
        alert.setTitle("View");
        alert.setMessage("Do you want View this item?");
        alert.setPositiveButton("YES", new OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
            	Toast.makeText(getApplicationContext(), 
                        "You have selected an item", Toast.LENGTH_LONG).show();
            }
        });
        alert.setNegativeButton("CANCEL", new OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // TODO Auto-generated method stub
                dialog.dismiss();
               }
        });
     
        alert.show();
     
    }
}