package com.zaptech.olxdemo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

public class RealEstate extends Activity 
{

	  ListView list;
	   String[] itemtext= {
			   "Duplexes","Bunglows","Flates","Corporate Houses","Shopes"
	   };
	   Integer[] imageId={
			   R.drawable.duplex_logo,
			   R.drawable.bunglow_logo,
			   R.drawable.flats_logo,
			   R.drawable.corporate_logo,
			   R.drawable.shop_logo,
			   	   
	   };
		@Override
		protected void onCreate(Bundle savedInstanceState) 
		{
			super.onCreate(savedInstanceState);
			setContentView(R.layout.realestate); 
			list = (ListView) findViewById(R.id.listView5);
			
				CustomList adapter = new CustomList(RealEstate.this, itemtext, imageId);
				list=(ListView)findViewById(R.id.listView5);
				        list.setAdapter(adapter);
				        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
				                @Override
				                public void onItemClick(AdapterView<?> parent, View view,
				                                        int position, long id) {
				                    if(position==0)
				                    	{
				                    		Intent intent= new Intent(RealEstate.this, MainActivity.class);
				                    		RealEstate.this.startActivity(intent);
				                    	}
				                    
				                   
				                }
				                
				                
				            });

	    }
}
