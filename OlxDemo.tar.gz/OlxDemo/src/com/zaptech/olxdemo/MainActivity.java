package com.zaptech.olxdemo;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;

public class MainActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
	}
 
	public void mobile (View v)
	{
		startActivity(new Intent(this, MobilePhone.class));
	}
	
	public void vehicle (View v)
	{
		startActivity(new Intent(this, Vehicle.class));
	}
	
	public void electronics (View v)
	{
		startActivity(new Intent(this, Electronics.class));
	}
	
	public void lifestyle (View v)
	{
		startActivity(new Intent(this, Lifestyle.class));
	}
	
	public void realestate (View v)
	{
		startActivity(new Intent(this, RealEstate.class));
	}
	
	public void job (View v)
	{
		startActivity(new Intent(this, Job.class));
	}
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

}
