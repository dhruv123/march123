package com.zaptech.olxdemo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

public class Electronics extends Activity 
{

	  ListView list;
	   String[] itemtext= {
			   "LED TVs","Refrigerators","Personal Computers","Laptops","Air Conditioners"
	   };
	   Integer[] imageId={
			   R.drawable.led_logo,
			   R.drawable.freez_logo,
			   R.drawable.pc_logo,
			   R.drawable.laptop_logo,
			   R.drawable.ac_logo,
			   	   
	   };
		@Override
		protected void onCreate(Bundle savedInstanceState) 
		{
			super.onCreate(savedInstanceState);
			setContentView(R.layout.electronics); 
			list = (ListView) findViewById(R.id.listView3);
			
				CustomList adapter = new CustomList(Electronics.this, itemtext, imageId);
				list=(ListView)findViewById(R.id.listView3);
				        list.setAdapter(adapter);
				        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
				                @Override
				                public void onItemClick(AdapterView<?> parent, View view,
				                                        int position, long id) {
				                    if(position==0)
				                    	{
				                    		Intent intent= new Intent(Electronics.this, MainActivity.class);
				                    		Electronics.this.startActivity(intent);
				                    	}
				                    
				                   
				                }
				                
				                
				            });

	    }
}
