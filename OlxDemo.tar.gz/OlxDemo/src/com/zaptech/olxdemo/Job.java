package com.zaptech.olxdemo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

public class Job extends Activity 
{

	  ListView list;
	   String[] itemtext= {
			   "Gevernment Jobs","Private Jobs","Part time Jobs "
	   };
	   Integer[] imageId={
			   R.drawable. gov_log,
			   R.drawable.private_logo,
			   R.drawable.part_logo,
			   	   
	   };
		@Override
		protected void onCreate(Bundle savedInstanceState) 
		{
			super.onCreate(savedInstanceState);
			setContentView(R.layout.job); 
			list = (ListView) findViewById(R.id.listView6);
			
				CustomList adapter = new CustomList(Job.this, itemtext, imageId);
				list=(ListView)findViewById(R.id.listView6);
				        list.setAdapter(adapter);
				        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
				                @Override
				                public void onItemClick(AdapterView<?> parent, View view,
				                                        int position, long id) {
				                    if(position==0)
				                    	{
				                    		Intent intent= new Intent(Job.this, MainActivity.class);
				                    		Job.this.startActivity(intent);
				                    	}
				                    
				                   
				                }
				                
				                
				            });

	    }
}
